package Class;

public class Mobile extends StallItem
{


    public Mobile(String name,String sid,double price)
    {
        this.name =name;
        this.sid = sid;
        this.price = price;

    }
    

    public void showInformation()   //abstract class StallItem er abstract method ..
    {
        

                            System.out.println("\t|----------------------------------------------------------|");
                            System.out.println("\t| MOBILE  NAME   => "+name+"                               ");
                            System.out.println("\t|                                                          |");
                            System.out.println("\t| STALL ID       => "+sid+"                                ");
                            System.out.println("\t|                                                          |");
                            System.out.println("\t| MOBILE PRICE   => "+price+"                              ");
                            System.out.println("\t|----------------------------------------------------------|");

    }
}