package Class;
import Interface.*;
import java.lang.*;

public class TechFairDirectory implements WorkerSetup,StallSetup
{

      private Worker workers[] = new Worker[50];
      private Stall stall[]=new Stall[100];

     public boolean addStall(Stall s)
    {
        for(int i=0; i<stall.length;i++)
        if (stall[i] == null)
        {
            stall[i] = s;
            return true;
        }
        return false;
    }
    public boolean removeStall(Stall s)
    {
        if (s==null) 
        return false;
        for(int i=0;i<stall.length;i++)
        {
            if(stall[i]== s)
            {
                stall[i]= null;
                return true;
            }
        }
        return false;    
    }

    public Stall findStall(String stl)
    {
        for (int i = 0; i<stall.length; i++)
        {
        if(stall[i]!= null && stall[i].getStl().equals(stl))  
        return stall[i];
        }
        return null;
    }

    public void showStallList()
    {
        boolean clear = false;
        for(int i = 0;i<stall.length;i++)
        if(stall[i] != null)
        {
            clear= true;
            break;
        }
        if(clear == false)
        {System.out.println("Empty Stall");}
        for(int i=0; i<stall.length;i++)
        if(stall[i] != null)
        {
            System.out.println("Stall Name: "+stall[i].getName());
            System.out.println("Stall ID  : "+stall[i].getStl());
            System.out.println();
        }
    }

    public boolean addWorker(Worker w)
    {
        for(int i = 0;i<workers.length;i++)
        if(workers[i] == null)
        {
            workers[i]= w;
            return true;
        }
        return false;
    }

    public boolean removeWorker(Worker w)
    {
        if(w == null)
        return false;
      for(int i=0; i<workers.length;i++)
      {
        if(workers[i]== w)
        {
            workers[i] = null;
            return true;
        }
      }
        return false;
    }

    public Worker findWorker(String wrkId)
    {
        for(int i=0;i<workers.length;i++)
        {
        if (workers[i] != null && workers[i].getWrkId().equals(wrkId))
        return workers[i];
        }
        return null;
    }
    public void showWorkerList()
    {
        boolean clear= false;
        for(int i=0;i<workers.length;i++)
        if(workers[i] != null)
        {
            clear = true;
            break;
        }
        if(clear== false)
        {
            System.out.println("Empty Worker");
        }
    
        for(int i=0;i<workers.length;i++)
        if(workers[i] != null)
        {
        	                System.out.println("\t|----------------------------------------------------------|");
                            System.out.println("\t| WORKER NAME   => "+workers[i].getName()+"                ");
                            System.out.println("\t|                                                          |");
                            System.out.println("\t| WORKER ID     => "+workers[i].getWrkId()+"               ");
                            System.out.println("\t|                                                          |");
                            System.out.println("\t| WORKER SALARY => "+workers[i].getSalary()+"              ");
                            System.out.println("\t|----------------------------------------------------------|");


           
        }
    }













}
