package Class;


import Interface.*; 

public class Stall implements StallItemSetup
{
    private String stl;
    private String name;
    private StallItem stlitem[] = new StallItem[50];

    public void setName(String name)
    {
        this.name = name;   
    }
    public String getName()
    {
        return name;
    }
    public void setStl(String stl)
    {
        this.stl = stl;
    }
    public String getStl()
    {
        return stl;
    }

    public boolean addStallItem(StallItem stm)
    {
        for(int i = 0; i<stlitem.length; i++)
        if(stlitem[i] == null)
        {
            stlitem[i] = stm;
            return true;
        }
        return false;
    }

    public boolean removeStallItem(StallItem stm)
    {
        if(stm == null)
        {
            return false;
        }
        for(int i = 0; i< stlitem.length; i++)
        {
            if(stlitem[i] == stm)
            {
                stlitem[i] = null;
                return true;
            }
        }
        return false;
    }

    public StallItem findStallItem(String item)
    {
        for(int i = 0; i<stlitem.length; i++)
            {
                if(stlitem[i] !=null && stlitem[i].getSid().equals(item));   
                {
                    return stlitem[i];
                }
                
            }
        return null;
    }

    public void showStallItem()
    {
        boolean clear = false;
        for(int i=0 ; i< stlitem.length;i++)
        {
            if(stlitem[i]  != null )
            {
                clear = true;
                break;
            }
        }
        if (clear == false) {
            System.out.println("Stall Item empty");
            return;
        }
        for(int i = 0;i<stlitem.length;i++)
        {
            if(stlitem[i] != null)
            {
                stlitem[i].showInformation();
            } 
        }
    }
}
