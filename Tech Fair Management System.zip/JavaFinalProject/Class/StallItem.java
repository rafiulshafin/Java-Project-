package Class;

import Interface.*;

public abstract class StallItem implements NumberOfItems
{
    protected String sid;
    protected String name;
    protected int availableNumber;
    protected double price;
    
    public void setSid(String sid)
    {
        this.sid  = sid;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public void setAvailableNumber(int availableNumber)
    {
        this.availableNumber= availableNumber;
    }
    public  void setPrice(double price)
    {
        this.price = price;
    }

    public String getSid()
    {
        return sid;
    }
    public String getName()
    {
        return name;
    }
    public int getAvailableNumber()
    {
        return availableNumber;
    }
    public double  getprice()
    {
        return price;
    }
    public abstract void showInformation();

    public boolean addNumber(int amount)
    {
        if (0<amount)
        {
            availableNumber = availableNumber + amount;
            return true;
        }
        return false;
    }
    
    public boolean sellNumber (int amount)
    {
        if(0<amount && amount <= availableNumber)
        {
            availableNumber= availableNumber - amount;
            return true;
        }
        return false;
    }

} 
