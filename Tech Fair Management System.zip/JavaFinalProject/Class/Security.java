package Class;

public class Security
{

	private String name;
	private String securityId;
	private String securityZone;

    public void setSecurityName(String name)
    {
        this.name = name;
    }
    public String getSecurityName()
    {
        return name;
    }
    public void setSecurityId(String securityId)
    {
        this.securityId = securityId;
    }
    public String getSecurityId()
    {
        return securityId;
    }
    public void setSecurityZone(String setSecurityZone)
    {
        this.securityZone=securityZone;
    }
    public String getSecurityZone()
    {
        return securityZone;
    }
}