package Class;

public class Worker
{

	private String name;
	private String wrkId;
	private double salary;

    public void setName(String name)
    {
        this.name = name;
    }
    public String getName()
    {
        return name;
    }
    public void setWrkId(String wrkId)
    {
        this.wrkId = wrkId;
    }
    public String getWrkId()
    {
        return wrkId;
    }
    public void setSalary(double salary)
    {
        this.salary = salary;
    }
    public double getSalary()
    {
        return salary;
    }
}