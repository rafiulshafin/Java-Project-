import java.lang.*;
import java.util.*;
import java.io.*;
import Class.*;
import FileIO.*;
import java.util.Scanner;

public class Main 
{
    public static void main(String[] args)
    {

        boolean a = true;
        Scanner input = new Scanner(System.in);
        FileIo frwd = new FileIo();    
        TechFairDirectory techFair = new TechFairDirectory();

        
        
        

        System.out.println();
        System.out.println("\t---------------------------------------------------------------------------------------------------");
        System.out.println("\t|                                                                                                 |");
        System.out.println("\t|                                     ╦ ╦╔╗╦ ╔╗╔╗╔╦╗╔╗                                            |");
        System.out.println("\t|                                     ║║║╠ ║ ║ ║║║║║╠                                             |");
        System.out.println("\t|                                     ╚╩╝╚╝╚╝╚╝╚╝╩ ╩╚╝                                            |");
        System.out.println("\t|                                                                                                 |");
        System.out.println("\t|                                                                                                 |");
        System.out.println("\t|                                                                                                 |");
        System.out.println("\t|                                                                                                 |");
        System.out.println("\t|                                                                                                 |");
        System.out.println("\t|                             ##  TECH FAIR MANAGEMENT SYSTEM  ##                                 |");
        System.out.println("\t|                                                                                                 |");
        System.out.println("\t|                                                                                                 |");
        System.out.println("\t|                                                                                                 |");
        System.out.println("\t---------------------------------------------------------------------------------------------------");


        
        while (a)
        {   
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 1. Worker Management                  |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 2. Stall Management                   |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 3. Stall Iteam Management             |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 4. Secuirity Management               |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 5. Exit                               |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("");
        System.out.println("");      
         

        System.out.println("\t|-------------------------------------------------------|");
        System.out.println("\t|                 Select an Option =>                   |");
        System.out.println("\t|-------------------------------------------------------|");   

            
            int option = input.nextInt();
            
            System.out.println("\n");
            switch(option)
            {
                
                case 1:
                {



        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |      ######### WORKER MANAGEMENT #########            |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 1. ADD WORKER                         |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 2. REMOVE WORKER                      |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 3. SHOW WORKER LIST                   |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 4. FIND WORKER                        |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |                 5. PREVIOUS PAGE                      |");
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("");
        System.out.println("");  

        System.out.println("\t|-------------------------------------------------------|");
        System.out.println("\t|                 Select an Option =>                   |");
        System.out.println("\t|-------------------------------------------------------|");   

                    int option1 = input.nextInt();
                    System.out.println();
                
                switch(option1)
                {
                    case 1:
                    {

                        System.out.println("\t                 |-------------------------------------------------------|");
                        System.out.println("\t                 |                 FOLLOW THE BELOW OPTIONS =>           |");
                        System.out.println("\t                 |-------------------------------------------------------|"); 
                        
                         System.out.println();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER WORKER ID =>                    |");
                        System.out.println("\t|-------------------------------------------------------|"); 

                        String wrkId = input.next();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| **              ENTER WORKER NAME =>                  |");
                        System.out.println("\t|-------------------------------------------------------|");

                        
                        String name = input.next();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| ***              ENTER WORKER SALARY =>               |");
                        System.out.println("\t|-------------------------------------------------------|");

                        
                        double salary = input.nextDouble();

                        
                        Worker w1 = new Worker();
                        w1.setWrkId(wrkId);
                        w1.setName(name);
                        w1.setSalary(salary);

                        if(techFair.addWorker(w1))
                        {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| ##ADDED WORKER ID IS => "+w1.getWrkId()+"             |");
                        System.out.println("\t|-------------------------------------------------------|");

                            
                        }
                        else
                        {
                           
                            System.out.println("Invalid");
                        }
                        System.out.println(" ");
                        break;
                    }
                     
                    case 2:
                    {
                        
                        System.out.println();
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER WORKER ID =>                    |");
                        System.out.println("\t|-------------------------------------------------------|"); 


                       
                        String wrkId2 = input.next();

                        Worker w2 = techFair.findWorker(wrkId2);

                        if(w2 != null)
                        {
                            if(techFair.removeWorker(w2))
                            {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| ##REMOVED WORKER ID IS => "+w2.getWrkId()+"           |");
                        System.out.println("\t|-------------------------------------------------------|");
                           }

                            else 
                            {
                               
                                System.out.println("INVALID");
                            }
                        }
                            else 
                            {
                                
                                System.out.println("ERROR...TRAY AGAIN");
                            }
                            System.out.println("");
                            break;
                    }

                    case 3:
                    {
                        System.out.println();
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               WORKER LIST =>                        |");
                        System.out.println("\t|-------------------------------------------------------|"); 


                        techFair.showWorkerList();

                        System.out.println();
                        break;
                    }

                    case 4:
                    {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               FIND WORKER =>                        |");
                        System.out.println("\t|-------------------------------------------------------|"); 

                        System.out.println("");

                        System.out.println("Enter Worker ID : ");
                        String wrkId4 = input.next();
                        
                        Worker w4 = techFair.findWorker(wrkId4);

                        if(w4 != null)
                        {
                            
                            System.out.println("\t|----------------------------------------------------------|");
                            System.out.println("\t| WORKER ID  => "+w4.getWrkId()+"                          |");
                            System.out.println("\t|                                                          |");
                            System.out.println("\t| WORKER NAME=> "+w4.getName()+"                           |");
                            System.out.println("\t|                                                          |");
                            System.out.println("\t| WORKER SALARY => "+w4.getSalary()+" taka                 |");
                            System.out.println("\t|----------------------------------------------------------|");

                        }
                        else 
                        {
                            System.out.println("NO MATCH WITH THE WORKER ID.....!!!  \n");
                            System.out.println("@TRY AGAIN@");
                        }
                        System.out.println();

                        break;
                    }
                    case 5:
                    {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t|                 LOADING MAIN MENU>>>>>>>>>>>>         |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                        System.out.println("");

                        break;
                    }
                    default:
                    {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t|                 INVALID OPTION <<<TRY AGAIN>>>        |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                    }
                }   
                System.out.println();
            }
                break; 
                
                case 2 :
                {
                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t|                 <<<<<STALL MANAGEMENT>>>>>            |");
                    System.out.println("\t|-------------------------------------------------------|"); 
                    System.out.println("");

                    
                    System.out.println("");

                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 1. ADD NEW STALL                      |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 2. REMOVE STALL                       |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 3. DISPLAY ALL STALL                  |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 4. FIND A STALL                       |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 5. PREVIOUS PAGE                      |");
                    System.out.println("\t                   |-------------------------------------------------------|");


                    System.out.println();
                    System.out.println();

                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t|                 Select an Option =>                   |");
                    System.out.println("\t|-------------------------------------------------------|"); 
                    int option2 = input.nextInt();
                    System.out.println();
                
                    switch(option2)
                    {
                    case 1:
                    {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t|                ####### ADD NEW STALL #######          |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                        System.out.println();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER STALL ID =>                     |");
                        System.out.println("\t|-------------------------------------------------------|"); 

                        String stlID1 = input.next();
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER STALL NAME =>                   |");
                        System.out.println("\t|-------------------------------------------------------|"); 

                        String stlN1 =input.next();

                        Stall stl1 = new Stall();
                        stl1.setStl(stlID1);
                        stl1.setName(stlN1);

                        if(techFair.addStall(stl1))
                        {
                            System.out.println("ADDED STALL ID IS : "+stl1.getStl());
                        }
                        else
                        {
                            System.out.println("MATCH NOT FOUND...!!!");
                        }

                        System.out.println();
                    }
                    System.out.println();
                    break;
                
                    case 2: 
                    {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t|           #######REMOVE STALL######                   |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                        System.out.println();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER STALL ID =>                     |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                        String stlID2 = input.next();

                        Stall stl2 = techFair.findStall(stlID2);

                    }
                    System.out.println();
                    break;

                    case 3:
                    {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t|                 ><><>DISPLAY ALL STALL><><>           |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                        System.out.println();

                        techFair.showStallList();    
                        System.out.println();
                    }
                    break;
                    case 4:
                    {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t|                 ><><>FIND A STALL <>><><              |");
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER STALL ID =>                     |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                        String stlID4 = input.next();

                        Stall stl4 = techFair.findStall(stlID4);
                        
                        if(stl4 != null)
                        {
                            
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *                STALL ID =>"+ stl4.getStl()           );
                        System.out.println("\t|-------------------------------------------------------|"); 
                        
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *                STALL NAME  =>"+ stl4.getName()       );
                        System.out.println("\t|-------------------------------------------------------|");

                        System.out.println();
                        System.out.println();

                            
                        }
                        else
                        {
                            System.out.println("NOT FOUND....!!??? \n");
                            
                        } 
                    }
                     System.out.println();
                     break;

                     case 5 :
                     {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t|                 PREVIOUS PAGE                         |");
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println();
                     }
                     System.out.println();
                     break;

                     default :
                     {
                        
                        System.out.println("INVALID ");
                        
                        System.out.println();
                     }
                
                    }
                    System.out.println();
                    break;
                }  
                case 3:
                {
                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t|          <<<<<<<<<<STALL ITEM MANAGEMENT>>>>>>>>>     |");
                    System.out.println("\t|-------------------------------------------------------|"); 
                    System.out.println();

                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 1. ADD NEW ITEM                       |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 2. REMOVE ITEM                        |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 3. DISPLAY ALL ITEMS                  |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 4. FIND A ITEM                        |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 5. PREVIOUS PAGE                      |");
                    System.out.println("\t                   |-------------------------------------------------------|");

                    System.out.println();
                    System.out.println();

                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t| *               ENTER OPTION =>                       |");
                    System.out.println("\t|-------------------------------------------------------|");
                    int option3 = input.nextInt();
                    input.nextLine();
                    System.out.println();
                
                    switch(option3)
                    {
                        case 1:
                        {
                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t|                 ##### ADD ITEM #####                  |");
                    System.out.println("\t|-------------------------------------------------------|"); 
                    
                        System.out.println();


                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 1. MOBILES                            |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 2. COMPUTERS                          |");
                    System.out.println("\t                   |-------------------------------------------------------|");
                    System.out.println("\t                   |                 3. PREVIOUS PAGE                      |");
                    System.out.println("\t                   |-------------------------------------------------------|");

                            
                       System.out.println("");

                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t| *               ENTER OPTION =>                       |");
                    System.out.println("\t|-------------------------------------------------------|");
                            int area = input.nextInt();
                            input.nextLine();

                            StallItem stlItem1 = null;   //Because StallItem is an abstract class .. thats why it has no object

                            if(area == 1)
                            {
                                
                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t| *               ENTER MOBILE NAME =>                  |");
                    System.out.println("\t|-------------------------------------------------------|");
                                String stlName1 = input.next();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER MOBILE ID =>                      |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                                String stlid1 = input.next();
                                
                               

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER MOBILE PRICE =>                   |");
                        System.out.println("\t|-------------------------------------------------------|");
                                double stlPrice1 = input.nextDouble();
                                input.nextLine();

                                

                                Mobile mobile1 = new Mobile(stlName1,stlid1,stlPrice1);

                                stlItem1 = mobile1;
                            }

                            else if(area == 2)
                            {
                               
                               

                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t| *               ENTER COMPUTER NAME =>                |");
                    System.out.println("\t|-------------------------------------------------------|");
                                String stlName2 = input.next();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER COMPUTER ID =>                  |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                                String stlid2 = input.next();

                               
                                
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER COMPUTER PRICE =>               |");
                        System.out.println("\t|-------------------------------------------------------|");
                                double stlPrice2 = input.nextDouble();

                               

                                Computer comp1 = new Computer(stlName2,stlid2,stlPrice2);

                                stlItem1 = comp1;
                            }

                            else if(area == 3)
                            {
                                System.out.println(" PREVIOUS PAGE");
                            }
                            else 
                            {
                                System.out.println("####INVALID####");
                            }
                            if(stlItem1 != null)
                            {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER STALL  ID =>                    |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                                String stlId1 = input.next();

                                Stall stl1 = techFair.findStall(stlId1);

                                if(stl1 != null)
                                {
                                    if(stl1.addStallItem(stlItem1))
                                    {
                                        System.out.println("ITEM ADDED");
                                        System.out.println("ITEM NUMBER =>  "+stlItem1.getSid());
                                    }
                                }
                                else
                                {
                                    System.out.println("####INVALID#####");

                                }
                                System.out.println("");
                            }
                            System.out.println("");
                        }
                        System.out.println("");
                        break;

                        case 2:
                        {
                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t|                 #### REMOVE ITEM ####                 |");
                    System.out.println("\t|-------------------------------------------------------|");
                            System.out.println();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER STALL  ID =>                    |");
                        System.out.println("\t|-------------------------------------------------------|"); 
                            String stlId2 = input.next();

                            Stall stl2 = techFair.findStall(stlId2);

                            if(stl2 != null)
                            {
                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t| *               ENTER ITEM NAME =>                  |");
                    System.out.println("\t|-------------------------------------------------------|");
                                String stlItemName1 = input.next();

                                StallItem stlitem2 = stl2.findStallItem(stlItemName1);

                                if(stlitem2 != null)
                                {
                                    if(stl2.removeStallItem(stlitem2))
                                    {
                                        
                                        System.out.println("ITEM NAME : "+stlitem2.getName());
                                    }
                                }
                                else
                                {
                                    
									System.out.println("ERORR..!!!...TRY AGAIN>>>");
                                }
                            }
                            else
                            {
                                System.out.println("<SOMETHING WENT WRONG>");
                            }
                        }
                        System.out.println("");
                        break;

                        case 3:
                        {
                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t|                  <><><> DISPLAY ALL ITEM <><><>       |");
                    System.out.println("\t|-------------------------------------------------------|");
                            System.out.println();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER STALL  ID =>                    |");
                        System.out.println("\t|-------------------------------------------------------|");
                            String stlId2 = input.next();

                            Stall stl2 = techFair.findStall(stlId2);
                            
                            if(stl2 != null)
                            {
                                stl2.showStallItem();
                            }
                            else
                            {
                                System.out.println("ERROR....!!!!"); 
                            }
                        }
                        System.out.println("");
                        break;

                        case 4:
                        {
                    System.out.println("\t|-------------------------------------------------------|");
                    System.out.println("\t|                 ##### FIND A ITEM ####                |");
                    System.out.println("\t|-------------------------------------------------------|");
                            System.out.println();

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER STALL  ID =>                    |");
                        System.out.println("\t|-------------------------------------------------------|");
                            String stlId3 = input.next();

                            Stall stl3 = techFair.findStall(stlId3);

                            if(stl3 != null)
                            {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t| *               ENTER STALL ITEM NAME =>                    |");
                        System.out.println("\t|-------------------------------------------------------|");
                                String stlItemName2 =  input.next();

                                StallItem stlItem3 = stl3.findStallItem(stlItemName2);

                                if(stlItem3 != null)
                                {
                                    
                                    stlItem3.showInformation();
                                    System.out.println();
                                }
                                else
                                {
                                    
									System.out.println("ERROR....TRY AGAIN>>>>");
                                }
                            }
                            else
                            {
                                System.out.println("SOMETHING WENT WRONG....CHECK IT AGAIN----->>>");
                            }    
                        }     
                        System.out.println();
                        break;

                        case 5 :
                        {
                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t|                 PREVIOUS PAGE                         |");
                        System.out.println("\t|-------------------------------------------------------|");
                            System.out.println();
                        }
                        break;

                        default:
                        {
                            
                            System.out.println("ERROR KEYWORD....TRY AGAIN--->> ");
                            
                            System.out.println();
                        }
                        break;
                    }
                }
                break;
                

                case 4:
                {
                            System.out.println("\t                   |-------------------------------------------------------|");
                            System.out.println("\t                   |                 # SECURITY MANAGEMENT #               |");
                            System.out.println("\t                   |-------------------------------------------------------|");
                            System.out.println("\t                   |                 1. ADD SECURITY                       |");
                            System.out.println("\t                   |-------------------------------------------------------|");
                            System.out.println("\t                   |                 2. SECURITY HISTORY                   |");
                            System.out.println("\t                   |-------------------------------------------------------|");
                            System.out.println("\t                   |                 3. PREVIOUS PAGE                      |");
                            System.out.println("\t                   |-------------------------------------------------------|");
                            System.out.println("");
                            System.out.println("");  

                        System.out.println("\t|-------------------------------------------------------|");
                        System.out.println("\t|                 Select an Option =>                   |");
                        System.out.println("\t|-------------------------------------------------------|");   

        
                                int option4=input.nextInt();

                    switch(option4)
                    {
                        case 1:
                        {
                            System.out.println("\t                 |-------------------------------------------------------|");
                            System.out.println("\t                 |                 FOLLOW THE BELOW OPTIONS =>           |");
                            System.out.println("\t                 |-------------------------------------------------------|"); 
                        
                            System.out.println();
                            System.out.println();
                            System.out.println();

                            System.out.println("\t|-------------------------------------------------------|");
                            System.out.println("\t| *               ENTER SECURITY GUARD ID =>            |");
                            System.out.println("\t|-------------------------------------------------------|"); 

                                String securityId = input.next();
                       
                            System.out.println();
                            System.out.println();

                            System.out.println("\t|-------------------------------------------------------|");
                            System.out.println("\t| **              ENTER SECURITY GUARD NAME =>          |");
                            System.out.println("\t|-------------------------------------------------------|");
                        
                            System.out.println();
                            System.out.println();

                        
                            String name = input.next();

                            System.out.println("\t|-------------------------------------------------------|");
                            System.out.println("\t| ***              ENTER SECURITY ZONE =>               |");
                            System.out.println("\t|-------------------------------------------------------|");

                            System.out.println();
                            System.out.println();

                        
                                String securityZone= input.next();

                            Security s1=new Security();
                            s1.setSecurityId(securityId);
                            s1.setSecurityName(name);
                            s1.setSecurityZone(securityZone);


                            System.out.println("\t|----------------------------------------------------------|");
                            System.out.println("\t| ##ADDED SECURITY GUARD ID IS => "+s1.getSecurityId()+"   |");
                            System.out.println("\t|                                                          |");
                            System.out.println("\t| ADDED SECURITY GUARD NAME IS => "+s1.getSecurityName()+" |");
                            System.out.println("\t|                                                          |");
                            System.out.println("\t| ##ADDED SECURITY ZONE IS => "+s1.getSecurityZone()+"     |");
                            System.out.println("\t|----------------------------------------------------------|");

                            System.out.println();
                            System.out.println();


                            frwd.writeInFile("Securiy ID: "+securityId+"\n"+"Securiy Guard Name: "+name+"\n"+"Securiy Zone :"+securityZone);  


                         }

                        break;

                        case 2:
                        {

                            System.out.println("\t                   |-------------------------------------------------------|");
                            System.out.println("\t                   |          <<<<<<<<<<< SECURITY HISTORY >>>>>>>>>>      |");
                            System.out.println("\t                   |-------------------------------------------------------|");
        
                            

                            frwd.readFromFile();
                        }

                      break;

        case 3:
        {
             System.out.println("Your OPtion is Go back to the previouse page");
              System.out.println();
        }
         System.out.println();
         break;

         default:
         {
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |           ##  INVALID INPUT !!!!!!!                   |");
        System.out.println("\t                   |-------------------------------------------------------|");
        
         }
       }
   }
   break;
    



                case 5:
                {
                    a = false;
	    System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |           THANK YOU FOR USING OUR SYSTEM              |");
        System.out.println("\t                   |-------------------------------------------------------|");
        
                    System.out.println();
                    
                }
                break;

                default:
                {
        System.out.println("\t                   |-------------------------------------------------------|");
        System.out.println("\t                   |           ##  SOMETHING WENT WRONG!!!!!!!             |");
        System.out.println("\t                   |-------------------------------------------------------|");
        
                }
            }
         
        }
        input.close();
       
    }
}


















