package Interface;

import Class.*;

public interface StallSetup
{
    boolean addStall(Stall s);

    boolean removeStall(Stall s);

    Stall findStall(String stl);

    public void showStallList();
}