import Interface;

import Class.*;

public interface SecuritySetup
{
    boolean addSecurity(Security s);
   
}