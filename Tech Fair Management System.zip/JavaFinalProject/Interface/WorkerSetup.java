package Interface;
import Class.*;

public interface WorkerSetup
{
    boolean addWorker(Worker w);

    boolean removeWorker(Worker w);

    Worker findWorker(String wrkId);


    public void showWorkerList();
}