package Interface;

public interface NumberOfItems
{
    boolean addNumber(int amount);
    boolean sellNumber(int amount);
}