package Interface;

import Class.*;

public interface StallItemSetup
{
    boolean addStallItem(StallItem stm);
    boolean removeStallItem(StallItem stm);

    StallItem findStallItem(String item);

    public void showStallItem();
}